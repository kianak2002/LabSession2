public class MusicTest {
    /**
     * To check musicplayer works or not.
     * @param args
     */
    public static void main(String[] args){
        MusicCollection[] categories=new MusicCollection[4];
//        MusicCollection hi=new MusicCollection();
        Music test=new Music("you are the reason","calum scott","2018");
        Music test1=new Music("hameh ragham mojood ast","kiosk","2012");
        Music test2=new Music("within attraction","yanni","2002");
        Music test3=new Music("derniere danse","indila","2010");
        Music test4=new Music("kedi gibi","tarkan","2016");
//        hi.addFile(test);
        for (int i=0;i<4;i++){
            categories[i]=new MusicCollection();
        }
        //add files to array list
        categories[0].addFile(test);
        categories[1].addFile(test1);
        categories[2].addFile(test2);
        categories[3].addFile(test3);
        categories[0].addFile(test4);
        categories[0].listAllFiles();
        //test all methods
        categories[0].startPlaying(0);
        categories[1].stopPlaying();
        categories[0].addPlaylist(1);
        categories[0].listPlaylist();
        categories[0].Search("kiosk");
        System.out.println(categories[0].getNumberOfFiles());
        categories[0].removeFile(1);
        categories[0].listAllFiles();
    }
}
