import java.util.ArrayList;
import java.util.Iterator;

/**
 * A class to hold details of audio files.
 *
 * @author David J. Barnes and Michael K�lling
 * @version 2011.07.31
 */
public class MusicCollection
{
    // An ArrayList for storing the file names of music files.
    private ArrayList<Music> files;
    private ArrayList<Music> playlist;
    // A player for the music files.
    private MusicPlayer player;


    /**
     * Create a MusicCollection
     */
    public MusicCollection()
    {
        files = new ArrayList<Music>();
        player = new MusicPlayer();
        playlist=new ArrayList<Music>();
    }

    /**
     * Add a file to the collection.
     * @param filename The file to be added.
     */
    public void addFile(Music filename)
    {
        files.add(filename);
    }

    /**
     * Return the number of files in the collection.
     * @return The number of files in the collection.
     */
    public int getNumberOfFiles()
    {
        return files.size();
    }

    /**
     * List a file from the collection.
     * @param index The index of the file to be listed.
     */
    public void listFile(int index)
    {
        if(validIndex(index)){
            System.out.println("file address is : "+files.get(index).getFileName());
            System.out.println("Music singer is : "+files.get(index).getSinger());
            System.out.println("file release date is  : "+files.get(index).getDate());
        }}

    /**
     * Show a list of all the files in the collection.
     */
    public void listAllFiles()
    {
        for(Music file : files){
            System.out.println("file address is : "+file.getFileName());
            System.out.println("Music singer is : "+file.getSinger());
            System.out.println("file release date is  : "+file.getDate());
        }
    }

    /**
     * Remove a file from the collection.
     * @param index The index of the file to be removed.
     */
    public void removeFile(int index)
    {
        if(validIndex(index)){
            files.remove(index);}
    }

    /**
     * Start playing a file in the collection.
     * Use stopPlaying() to stop it playing.
     * @param index The index of the file to be played.
     */
    public void startPlaying(int index)
    {
        if(validIndex(index)){
            String name=files.get(index).getFileName();
            player.startPlaying(name);
        }}

    /**
     * Stop the player.
     */
    public void stopPlaying()
    {
        player.stop();
    }


    /**
     * Determine whether the given index is valid for the collection.
     * Print an error message if it is not.
     * @param index The index to be checked.
     * @return true if the index is valid, false otherwise.
     */
    private boolean validIndex(int index)
    {
        // The return value.
        // Set according to whether the index is valid or not.
        if(index >= 0 && index < files.size())
            return true;
        else {
            System.out.println("This index is not valid");
            return false;
        }
    }
    /**
     * Add a file to playlist.
     * @param  index The file to be added.
     */
    public void addPlaylist(int index){
        if(validIndex(index)){
            playlist.add(files.get(index));
        }}
    /**
     *  Remove a file from playlist.
     * @param Toremove The file removed
     */
    public void rempvePlaylist(Music Toremove){
        playlist.remove(Toremove);
    }
    public void listPlaylist(){
        Iterator<Music> it=playlist.iterator();
        while (it.hasNext()){
            Music play=it.next();
            System.out.println("file address is : "+play.getFileName());
            System.out.println("Music singer is : "+play.getSinger());
            System.out.println("file release date is  : "+play.getDate());
        }
    }
    /**
     * Search between musics.
     * @param name name of singer or file name
     */
    public void Search(String name){
        Iterator<Music> it=files.iterator();
        int counter=0;
        while (it.hasNext()){
            counter++;
            Music music=it.next();
            if (music.getSinger().equals(name)||music.getFileName().equals(name)){
                listFile(counter);
            }
        }
    }
}
