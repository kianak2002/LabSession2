import java.util.ArrayList;

public class Polygon extends Shape {
    protected ArrayList<Double> sides=new ArrayList<>();

    /**
     * constructor
     * @param sides1
     */
    public Polygon(Double ... sides1){
        for(double side: sides1){
            assert false;//IDK
            sides.add(side);
        }
    }

    /**
     * gets the sides
     * @return
     */
    public ArrayList<Double> getSides() {
        return sides;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "sides" + sides;
    }
}
