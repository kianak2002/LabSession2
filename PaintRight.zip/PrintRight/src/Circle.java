import java.util.ArrayList;

public class Circle extends Shape{
    private double radius;

    /**
     * constructor
     * @param radius
     */
    public Circle(double radius){
        this.radius = radius;
    }

    /**
     * gets the radius
     * @return
     */
    public double getRadius() {
        return radius;
    }

    /**
     * calculates the perimeter of the circle
     * @param sides
     * @return
     */
    @Override
    public double calculatePerimeter(double... sides) {
        return 2 * radius * Math.PI;
    }

    /**
     * calculates the area of the circle
     * @param sth
     * @return
     */
    @Override
    public double calculateArea(double... sth) {
        return radius * radius * Math.PI;
    }

    /**
     * prints the perimeter and area
     */
    @Override
    public void draw() {
        System.out.println("circle");
        System.out.println("perimeter: " + calculatePerimeter());
        System.out.println("area: " + calculateArea());
    }

    /**
     * checks if two circles are equal
     * @param shape
     * @return
     */
    @Override
    public boolean equals(Shape shape) {
        return this.radius == radius;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return super.toString();
    }
}
