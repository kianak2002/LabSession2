import java.util.ArrayList;

public class Paint {
    ArrayList<Shape> shapes;

    /**
     * constructor
     */
    public Paint(){
        shapes = new ArrayList<>();
    }

    /**
     * add shape to the arrayList
     * @param shape
     */
    public void addShape(Shape shape) {
        shapes.add(shape);
    }

    /**
     * draw shapes
     */
    public void drawAll(){
        for(Shape shape: shapes){
            shape.draw();
        }
    }

    /**
     * print shapes with toString
     */
    public void printAll(){
        for (Shape shape: shapes){
            shape.toString();
        }
    }

    /**
     * checks if the triangle is equilateral triangle
     * checks if it is square or not
     */
    public void describeEqualSides(){
        for(Shape shape: shapes){
            if(shape instanceof Triangle){
                if(((Triangle) shape).isEquilateral())
                    System.out.println("Equilateral Triangle");
            }
            else if(shape instanceof Rectangle){
                if(((Rectangle) shape).isSquare())
                    System.out.println("Square");
            }
        }
    }
}
