import java.util.ArrayList;

public class Rectangle extends Polygon {

    /**
     * constructor
     * @param args
     */
    public Rectangle(Double... args){
        super(args);
    }

    /**
     * calculates the perimeter of the rectangle
     * @param sth
     * @return
     */
    @Override
    public double calculatePerimeter(double... sth) {
        return sides.get(0) + sides.get(1) + sides.get(2) + sides.get(3);
    }

    /**
     * calculates the area of the rectangle
     * @param sth
     * @return
     */

    @Override
    public double calculateArea(double... sth) {
        if(!sides.get(0).equals(sides.get(1)))
            return sides.get(0) * sides.get(1);
        else if (!sides.get(0).equals(sides.get(2)))
            return sides.get(0) * sides.get(2);
        else
            return sides.get(0) * sides.get(0); // square
    }

    /**
     * prints the perimeter and area
     */
    @Override
    public void draw() {
        System.out.println("Rectangle");
        System.out.println("perimeter: " + calculatePerimeter());
        System.out.println("area: " + calculateArea());
    }

    /**
     * checks if two rectangles are equal
     * @param shape
     * @return
     */
    @Override
    public boolean equals(Shape shape) {
        return sides.contains(sides.get(1)) && sides.contains(sides.get(2))
                && sides.contains(sides.get(3)) && sides.contains(sides.get(4));
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "Rectangle: " + super.toString();
    }

    /**
     * checks if it is square or not
     * @return
     */
    public boolean isSquare(){
        return sides.get(0).equals(sides.get(1)) && sides.get(1).equals(sides.get(2)) && sides.get(2).equals(sides.get(3));
    }
}
