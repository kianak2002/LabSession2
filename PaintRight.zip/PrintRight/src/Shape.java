public class Shape {
    /**
     * calculates the perimeter
     * @param sides
     * @return
     */
    public double calculatePerimeter(double ... sides){
        double perimeter = 0;
        for(double side: sides){
            perimeter += side;
        }
        return perimeter;
    }

    /**
     * calculates the area
     * @param sth
     * @return
     */
    public double calculateArea(double ... sth){
        double area = 0;
        for(double side: sth){
            area *= side;
        }
        return area;
    }

    /**
     * prints the perimeter and area
     */
    public void draw(){
        System.out.println("shape");
        System.out.println("perimeter: " + calculatePerimeter());
        System.out.println("area: " + calculateArea());
    }

    /**
     *
     * @param shape
     * @return
     */
    public boolean equals(Shape shape){
        return shape == shape;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "Shape: " ;
    }

}
