import java.util.ArrayList;

public class Triangle extends Polygon {
    /**
     * constructor
     * @param args
     */
    public Triangle(Double... args){
        super(args);

    }

    /**
     * calculates the perimeter of the perimeter
     * @param sth
     * @return
     */
    @Override
    public double calculatePerimeter(double... sth) {
        return sides.get(0) + sides.get(1) + sides.get(2);
    }

    /**
     * calculates the area of the triangle
     * @param sth
     * @return
     */
    @Override
    public double calculateArea(double... sth) {
        double p = (sides.get(0) + sides.get(1) + sides.get(2))/2;
        return Math.sqrt(p * (p - sides.get(0)) * (p - sides.get(1)) * (p - sides.get(2)));
    }

    /**
     * prints the perimeter and area
     */
    @Override
    public void draw() {
        System.out.println("triangle");
        System.out.println("perimeter: " + calculatePerimeter());
        System.out.println("area: " + calculateArea());
    }

    /**
     * checks if two triangles are equal
     * @param shape
     * @return
     */
    @Override
    public boolean equals(Shape shape) {
        return sides.contains(sides.get(0)) && sides.contains(sides.get(1)) && sides.contains(sides.get(2));
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "Triangle: " + super.toString();
    }

    /**
     * checks if it is equilateral triangle
     * @return
     */
    public boolean isEquilateral(){
        return sides.get(0).equals(sides.get(1)) && sides.get(1).equals(sides.get(2));
    }
}
