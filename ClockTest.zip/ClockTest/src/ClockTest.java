public class ClockTest {
    public static void main(String args[]){
        ClockDisplay clockDisplay = new ClockDisplay();
        System.out.println(clockDisplay.getTime());
        clockDisplay.timeTick2();
        clockDisplay.timeTick();
        System.out.println(clockDisplay.getTime());
        ClockDisplay clockDisplay1 = new ClockDisplay(0, 59,59);
        System.out.println(clockDisplay1.getTime());
        clockDisplay1.timeTick2();
        clockDisplay1.timeTick();
        System.out.println(clockDisplay1.getTime());
    }
}
