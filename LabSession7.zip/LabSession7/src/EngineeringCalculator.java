import javax.swing.*;
import java.awt.*;

public class EngineeringCalculator {
    JFrame f;

    public EngineeringCalculator() {
        JTextArea input = new JTextArea();
        f = new JFrame();
        JTextArea ta = new JTextArea(200, 200);
        JPanel p1 = new JPanel();
        p1.add(ta);
        JPanel p2 = new JPanel();
        JTabbedPane tp = new JTabbedPane(SwingConstants.TOP);
        tp.setBounds(50, 50, 200, 200);
        tp.add("basic", p1);
        tp.add("engineering", p2);
        f.add(tp);
        f.setSize(400, 400);
        f.setLayout(null);
        f.setVisible(true);



        JFrame frame = new JFrame();
        JPanel panel = new JPanel();
        JButton one = new JButton("1");
        JButton two = new JButton("2");
        JButton three = new JButton("3");
        JButton four = new JButton("4");
        JButton five = new JButton("5");
        JButton six = new JButton("6");
        JButton seven = new JButton("7");
        JButton eight = new JButton("8");
        JButton nine = new JButton("9");
        JButton zero = new JButton("0");

        JButton plus = new JButton("+");
        JButton minus = new JButton("-");
        JButton divide = new JButton("/");
        JButton multiply = new JButton("*");
        JButton log = new JButton("log");
        JButton percentage = new JButton("%");
        JButton equals = new JButton("=");
        JButton sin = new JButton("sin/cos");
        JButton tan = new JButton("tan/cot");
        JButton shift = new JButton("SHIFT");

        JTextArea display = new JTextArea(100, 100);
        display.setEditable(false);
        display.setFont(new Font("Arial", 14, 50));
        frame.add(display);

        JScrollPane scrollPane = new JScrollPane(display);
        //scrollPane.setPreferredSize(new Dimension(500, 400));
        scrollPane.setSize(200, 100);
        scrollPane.setLocation(75, 40);
        frame.getContentPane().add(scrollPane);



        JLabel label = new JLabel("Engineering Calculator");
        frame.getContentPane().add(BorderLayout.NORTH, label);

        frame.getContentPane().add(BorderLayout.SOUTH, input);

        panel.setBackground(Color.ORANGE);
        panel.setLayout(new GridBagLayout());

        JPanel panel2 = new JPanel();
        panel2.setLayout(new BoxLayout(panel2, BoxLayout.Y_AXIS));
        panel2.setBackground(Color.GRAY);
        frame.getContentPane().add(BorderLayout.EAST, panel2);

        frame.getContentPane().add(BorderLayout.CENTER, panel);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setSize(500, 500);


        GridBagConstraints right = new GridBagConstraints();
        right.anchor = GridBagConstraints.WEST;
        GridBagConstraints left = new GridBagConstraints();
        left.anchor = GridBagConstraints.EAST;
        GridBagConstraints middle = new GridBagConstraints();
        middle.anchor = GridBagConstraints.CENTER;
        right.gridwidth = GridBagConstraints.REMAINDER;
        right.fill = GridBagConstraints.HORIZONTAL;

        // add buttons
        panel.add(one, left);
        panel.add(two, middle);
        panel.add(three, right);
        panel.add(four, left);
        panel.add(five, middle);
        panel.add(six, right);
        panel.add(seven, left);
        panel.add(eight, middle);
        panel.add(nine, right);
        panel.add(zero, right);

        panel2.add(equals);
        panel2.add(plus);
        panel2.add(minus);
        panel2.add(divide);
        panel2.add(multiply);
        panel2.add(log);
        panel2.add(percentage);
        panel2.add(sin);
        panel2.add(tan);
        panel2.add(shift);
    }


}


