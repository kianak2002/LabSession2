import javax.swing.UIManager;

public class Main {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ex) {
            System.err.println(ex.getMessage());
        }

        EngineeringCalculator engineeringCalculator = new EngineeringCalculator();
        //engineeringCalculator.screen();
        //CalculatorGUI calculator = new CalculatorGUI();
        BasicCalculatorDesign basicCalculatorDesign = new BasicCalculatorDesign();
        basicCalculatorDesign.start();
    }
}
