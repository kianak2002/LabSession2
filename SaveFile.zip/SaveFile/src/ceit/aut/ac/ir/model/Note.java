package ceit.aut.ac.ir.model;
// TODO: Phase2: uncomment this code
public class Note {

    private String title;
    private String content;
    private String date;

    /**
     * constructor
     * @param title
     * @param content
     * @param date
     */
    public Note(String title, String content, String date) {
        this.title = title;
        this.content = content;
        this.date = date;
    }

    @Override
    public String toString() {
        return "Note{" +
                "title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", date='" + date + '\'' +
                '}';
    }

}

