package ceit.aut.ac.ir.gui;

import ceit.aut.ac.ir.gui.CMainPanel;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class CFrame extends JFrame implements ActionListener {

    private CMainPanel mainPanel;

    private JMenuItem newItem;
    private JMenuItem saveItem;
    private JMenuItem exitItem;

    /**
     * constructor
     * @param title
     */
    public CFrame(String title) {
        super(title);

        initMenuBar(); //create menuBar

        initMainPanel(); //create main panel
    }

    /**
     * building menus and adding actionListener to them
     */
    private void initMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu jmenu = new JMenu("File");

        newItem = new JMenuItem("New");
        saveItem = new JMenuItem("Save");
        exitItem = new JMenuItem("Exit");

        newItem.addActionListener(this);
        saveItem.addActionListener(this);
        exitItem.addActionListener(this);

        jmenu.add(newItem);
        jmenu.add(saveItem);
        jmenu.add(exitItem);

        menuBar.add(jmenu);
        setJMenuBar(menuBar);
    }

    /**
     * create mainPanel
     */
    private void initMainPanel() {
        mainPanel = new CMainPanel();
        add(mainPanel);
    }

    /**
     * @param e
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == newItem) {
            mainPanel.addNewTab();
        } else if (e.getSource() == saveItem) {
            try {
                mainPanel.saveNote();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        } else if (e.getSource() == exitItem) {
            //TODO: Phase1: check all tabs saved ...
            int index = mainPanel.getTabbedPane().getTabCount();
            while(index != 0) { //saving all tabs
                mainPanel.getTabbedPane().setSelectedIndex(--index);
                try {
                    mainPanel.saveNote();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
            System.exit(0);
        } else {
            System.out.println("Nothing detected...");
        }
    }
}
