package ceit.aut.ac.ir.utils;

import ceit.aut.ac.ir.model.Note;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.logging.SimpleFormatter;

public class FileUtils {

    private static final String NOTES_PATH = "./notes/";

    //It's a static initializer. It's executed when the class is loaded.
    //It's similar to constructor
    static {
        boolean isSuccessful = new File(NOTES_PATH).mkdirs();
        System.out.println("Creating " + NOTES_PATH + " directory is successful: " + isSuccessful);
    }

    public static File[] getFilesInDirectory() {
        return new File(NOTES_PATH).listFiles();
    }

    /**
     * reading from file
     * @param file
     * @return
     * @throws IOException
     */
    public static String fileReader(File file) throws IOException {
        //TODO: Phase1: read content from file
//        FileReader fr = new FileReader(file);
//
//        int i;
//        while ((i=fr.read()) != -1)
//            System.out.print((char) i);

        try {
            File myObj = new File("filename.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                System.out.println(data);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        return "";
    }

    /**
     * writing to file
     * @param content
     * @throws IOException
     */
    public static void fileWriter(String content) throws IOException {
        //TODO: write content on file
        String fileName = getProperFileName(content);
//        FileWriter fileWriter = new FileWriter(fileName);
//        fileWriter.write(content);

        Date date = new Date();
        SimpleDateFormat simpleFormatter = new SimpleDateFormat("YYYY/MM/DD  HH:MM:SS");
        PrintWriter writer = new PrintWriter(fileName, "UTF-8");
        Note note = new Note("title", content, simpleFormatter.format(date));
        FileOutputStream file = new FileOutputStream(fileName);
        try (file){
            String newContent = note.toString();
            file.write(newContent.getBytes());
        } catch (IOException e){
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        writer.println(content);
        writer.close();


//        try {
//            File myObj = new File(fileName);
//            if (myObj.createNewFile()) {
//                System.out.println("File created: " + myObj.getName());
//            } else {
//                System.out.println("File already exists.");
//            }
//        } catch (IOException e) {
//            System.out.println("An error occurred.");
//            e.printStackTrace();
//        }
        }

    /**
     * reading from file with bufferedReader
     * @param file
     * @throws IOException
     */
    public static void bufferedReader(File file) throws IOException {

        //File file = new File("C:\\Users\\pankaj\\Desktop\\test.txt");
        BufferedReader br = new BufferedReader(new FileReader(file));
        String st;
        while ((st = br.readLine()) != null)
            System.out.println(st);
    }

    /**
     * writting to file with bufferedWriter
     * @param content
     * @throws IOException
     */
    public static void bufferedWriter(String content) throws IOException{
        String fileName = getProperFileName(content);
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
        writer.write(content);
        writer.close();
    }

    /**
     * reading from file with inputStream
     * @param file
     */
    //TODO: Phase1: define method here for reading file with InputStream
    public static void fileReadInputStream(File file){
        try (InputStream in = new FileInputStream(file)) {
            int content;
            while ((content = in.read()) != -1) {
                System.out.print((char)content);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * writing in file with outPutStream
     * @param content
     */
    //TODO: Phase1: define method here for writing file with OutputStream
    public static void fileWriteOutputStream(String content){
        try{
            String fileName = getProperFileName(content);
            FileOutputStream fout=new FileOutputStream(fileName);

            byte b[]=content.getBytes();//converting string into byte array
            fout.write(b);
            fout.close();
            System.out.println("success...");
        }catch(Exception e){System.out.println(e);}
    }

    //TODO: Phase2: proper methods for handling serialization

    /**
     * makes the fileName
     * @param content
     * @return
     */
    private static String getProperFileName(String content) {
        int loc = content.indexOf("\n");
        if (loc != -1) {
            return content.substring(0, loc);
        }
        if (!content.isEmpty()) {
            return content;
        }
        return System.currentTimeMillis() + "_new file.txt";
    }
}
