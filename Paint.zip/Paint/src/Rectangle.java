import java.util.ArrayList;
import java.util.Objects;

public class Rectangle {
    private ArrayList<Double> sides;

    /**
     * constructor
     * @param side1
     * @param side2
     * @param side3
     * @param side4
     */
    public Rectangle(double side1, double side2, double side3, double side4){
        sides = new ArrayList<>();
        sides.add(side1);
        sides.add(side2);
        sides.add(side3);
        sides.add(side4);
    }

    /**
     * calculates the perimeter of rectangle
     * @return
     */
    public double calculatePerimeter(){
        return sides.get(0) + sides.get(1) + sides.get(2) + sides.get(3);
    }

    /**
     * calculates the area of area
     * @return
     */
    public double calculateArea(){
        if(!sides.get(0).equals(sides.get(1)))
            return sides.get(0) * sides.get(1);
        else if (!sides.get(0).equals(sides.get(2)))
            return sides.get(0) * sides.get(2);
        else
            return sides.get(0) * sides.get(0); // square
    }

    /**
     * prints perimeter and area
     */
    public void draw(){
        System.out.println("Rectangle");
        System.out.println("perimeter: " + calculatePerimeter());
        System.out.println("area: " + calculateArea());
    }

    /**
     * checks if two triangles are equal
     * @param o
     * @return
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Rectangle rectangle = (Rectangle) o;
        return Objects.equals(sides, rectangle.sides);
    }

    @Override
    public int hashCode() {
        return Objects.hash(sides);
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "Rectangle: " + sides.get(0) + "," + sides.get(1) + "," + sides.get(2) + "," + sides.get(3);
    }

    /**
     * gets the sides
     * @return
     */
    public ArrayList<Double> getSides() {
        return sides;
    }

    /**
     * checks if it is square or not
     * @return
     */
    public boolean isSquare(){
        return sides.get(0).equals(sides.get(1)) && sides.get(1).equals(sides.get(2)) && sides.get(2).equals(sides.get(3));
    }
}
