import java.util.ArrayList;

public class Paint {
    private ArrayList<Triangle> triangles = new ArrayList<>();
    private ArrayList<Circle> circles = new ArrayList<>();
    private ArrayList<Rectangle> rectangles = new ArrayList<>();

    /**
     * constructor
     */
    public Paint(){
        triangles = new ArrayList<>();
        circles = new ArrayList<>();
        rectangles = new ArrayList<>();
    }

    /**
     * adds triangle to the arrayList
     * @param triangle
     */
    public void addTriangle(Triangle triangle){
        triangles.add(triangle);
    }

    /**
     * adds circle to the arrayList
     * @param circle
     */
    public void addCircle(Circle circle){
        circles.add(circle);
    }

    /**
     * adds rectangle to the arrayList
     * @param rectangle
     */
    public void addRectangle(Rectangle rectangle){
        rectangles.add(rectangle);
    }

    /**
     * draw all shapes
     */
    public void drawAll(){
        for(Triangle triangle: triangles){
            triangle.draw();
        }
        for(Circle circle: circles){
            circle.draw();
        }
        for(Rectangle rectangle: rectangles){
            rectangle.draw();
        }
    }

    /**
     * print all shapes with toString
     */
    public void printAll(){
        for(Triangle triangle: triangles){
            System.out.println(triangle.toString());
        }
        for(Circle circle: circles){
            System.out.println(circle.toString());
        }
        for(Rectangle rectangle: rectangles){
            System.out.println(rectangle.toString());
        }
    }
}
