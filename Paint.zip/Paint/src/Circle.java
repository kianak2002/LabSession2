import java.util.Objects;

public class Circle {
    private double radius;

    /**
     * constructor
     * @param radius
     */
    public Circle(double radius){
        this.radius = radius;
    }

    /**
     * calculates the perimeter of circle
     * @return
     */

    public double calculatePerimeter(){
        return 2 * radius * Math.PI;
    }

    /**
     * calculates the area of circle
     * @return
     */
    public double calculateArea(){
        return radius * radius * Math.PI;
    }

    /**
     * prints perimeter and area
     */
    public void draw(){
        System.out.println("circle");
        System.out.println("perimeter: " + calculatePerimeter());
        System.out.println("area: " + calculateArea());
    }

    /**
     * checks if two triangles are equal
     * @param o
     * @return
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Circle circle = (Circle) o;
        return Double.compare(circle.radius, radius) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(radius);
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "Circle: " + radius;
    }

    /**
     * gets the radius
     * @return
     */
    public double getRadius() {
        return radius;
    }
}
