import ir.huri.jcal.JalaliCalendar;

import java.util.Objects;

public class Vote {
    private Person person;
    private String date;
    private JalaliCalendar jalaliCalendar = new JalaliCalendar();

    public Vote(Person person, String date){
        this.person = person;
        this.date = date;
    }

    /**
     * gets person
     * @return
     */
    public Person getPerson() {
        return person;
    }

    /**
     * gets date
     * @return
     */
    public String getDate() {
        return date;
    }

    /**
     *
     * @param o
     * @return
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Vote vote = (Vote) o;
        return person.equals(vote.person) &&
                date.equals(vote.date);
    }

    /**
     *
     * @return
     */
    @Override
    public int hashCode() {
        return Objects.hash(person, date);
    }
}
