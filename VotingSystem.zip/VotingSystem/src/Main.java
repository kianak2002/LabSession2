import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        VotingSystem votingSystem = new VotingSystem();
        ArrayList<String> options1 = new ArrayList<>();
        options1.add("Coffee");
        options1.add("cappuccino");
        options1.add("Tea");
        votingSystem.createVoting("Best Beverage",0,options1);
        Voting voting1 = new Voting(0, "Best Beverage");
        voting1.createPoll("Coffee");
        voting1.createPoll("Cappuccino");
        voting1.createPoll("Tea");
        ArrayList<String> options2 = new ArrayList<>();
        options2.add("Farsi");
        options2.add("Chinese");
        options2.add("French");
        options2.add("Spanish");
        options2.add("Italian");
        Voting voting2 = new Voting(1,"Hardest Languages");
        votingSystem.createVoting("Hardest Language", 1, options2);
        voting2.createPoll("Farsi");
        voting2.createPoll("Chinese");
        voting2.createPoll("French");
        voting2.createPoll("Spanish");
        voting2.createPoll("Italian");
        /**
         * gets the name from the user
         * prints the options
         * gets a choice from user
         * gets the name of the second user
         * prints the options again
         * gets a choice from user
         * prints the result
         */
        Person voter1 = new Person(scanner.next(), scanner.next());
        voting1.printOptions();
        ArrayList<String> votes1 = new ArrayList<>();
        votes1.add(scanner.next());
        votingSystem.vote(0, voter1, votes1);
        Person voter2 = new Person(scanner.next(), scanner.next());
        voting1.printOptions();
        votes1.add(scanner.next());
        votingSystem.getResult(0);
        /**
         * gets the name from user
         * prints the options of the second voting
         * gets a choice from user
         * gets the name of the second user
         * prints the options again
         * gets a choice from user
         * prints the result
         */
        Person voter3 = new Person(scanner.next(), scanner.next());
        voting2.printOptions();
        ArrayList<String> votes2 = new ArrayList<>();
        votes2.add(scanner.next());
        votingSystem.vote(1, voter3, votes2);
        Person voter4 = new Person(scanner.next(), scanner.next());
        voting2.printOptions();
        votes2.add(scanner.next());
        votingSystem.vote(1, voter4, votes2);
        votingSystem.getResult(1);


    }
}
