import ir.huri.jcal.JalaliCalendar;

import java.util.*;

public class Voting {
    private int type;
    private String question;
    private ArrayList <Person> voters;
    private HashMap<String, HashSet<Vote>> polls = new HashMap<>();

    public Voting(int type, String question){
        this.type = type;
        this.question = question;
    }

    /**
     * gets question
     * @return
     */

    public String getQuestion() {
        return question;
    }

    /**
     * adds an option to the voting
     * @param option
     */
    public void createPoll(String option){
        polls.put(option, new HashSet<Vote>());
    }

    /**
     * gets the voter and votes
     * add the vote to the votes and add the voter to the voters
     * @param person
     * @param votes
     */
    public void vote(Person person, ArrayList<String> votes){
        JalaliCalendar jalaliCalendar = new JalaliCalendar();
        Vote ray = new Vote(person, jalaliCalendar.toString());
        if((type == 0 && votes.size() == 1) || type == 1){
            for(String root: votes){
                HashSet<Vote> sth = polls.get(root);
                if(sth == null){
                    sth = new HashSet<>();
                }
                sth.add(ray);
                polls.put(root, sth);
//                voters.add(person);
            }
        }
        else{
            System.out.println("Type of vote is wrong");
        }
    }

    /**
     * gets the voters
     * @return
     */
    public ArrayList<Person> getVoters() {
        return voters;
    }

    /**
     * prints the options
     */
    public void printOptions(){
        System.out.println("options: ");
        for(Map.Entry<String, HashSet<Vote>> first : polls.entrySet()){
            System.out.println(first.getKey());
        }
    }

    /**
     * prints the votes
     */
    public void printVotes(){
        System.out.println();
        for(Map.Entry<String, HashSet<Vote>> root : polls.entrySet()){
            System.out.println(root.getKey());
            System.out.println(root.getValue());
        }
    }

    /**
     * gets the polls
     * @return
     */
    public HashMap<String, HashSet<Vote>> getPolls() {
        return polls;
    }

    /**
     * calculate the results and prints it
     */
    public void getResult(){
        HashMap<String, Integer> count = new HashMap<>();
        for(Map.Entry<String, HashSet<Vote>> help : polls.entrySet()){
            count.put(help.getKey(), help.getValue().size());
        }
        int max = Collections.max(count.values());
        for(Map.Entry<String, Integer> entry: count.entrySet()){
            if(entry.getValue() == max){
                System.out.println(entry.getKey());
            }
        }
    }
}
