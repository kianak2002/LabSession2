import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class VotingSystem {
    private ArrayList<Voting> votingList;

    public VotingSystem() {
        votingList = new <Voting>ArrayList();
    }

    /**
     * gets votingList
     * @return
     */
    public ArrayList<Voting> getVotingList() {
        return votingList;
    }

    /**
     * create a voting by giving the question and options for answer
     * if type is 1 voter can choose some of the options
     * if type is 0 voter can choose only one option
     * @param question
     * @param type
     * @param options
     */
    public void createVoting(String question, int type, ArrayList<String> options) {
        Voting voting = new Voting(type, question);
        for(String root: options){
            voting.createPoll(root);
        }
        votingList.add(voting);
    }

    /**
     * get the vote of the voter and add it to votingList
     * @param index
     * @param person
     * @param votes
     */
    public void vote(int index, Person person, ArrayList<String> votes) {
        votingList.get(index).vote(person, votes);
    }

    /**
     * prints the result of the voting
     * @param index
     */
    public void getResult(int index) {
        System.out.println("RESULT: ");
        votingList.get(index).getResult();
    }
}
