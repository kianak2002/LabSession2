import javax.swing.*;
import java.awt.event.KeyEvent;
import java.awt.Event;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;


public class Main {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ex) {
            System.err.println(ex.getMessage());
        }

        JFrame frame = new JFrame();
        frame.setSize(1000,1000);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JTabbedPane tp1 = new JTabbedPane(SwingConstants.TOP);

        EngineeringCalculator engineeringCalculator = new EngineeringCalculator(frame, tp1);
        BasicCalculatorDesign basicCalculatorDesign = new BasicCalculatorDesign(frame, tp1);

        JMenuBar menuBar = new JMenuBar();

        // File Menu, F - Mnemonic
        JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic(KeyEvent.VK_F);
        menuBar.add(fileMenu);

        class EditListener implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                System.out.println(e.getActionCommand());
            }
        }

        EditListener l = new EditListener();
        // File->New, N - Mnemonic
        JMenuItem exitMenuItem = new JMenuItem("Exit", KeyEvent.VK_N);
        exitMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Exit performed");
                System.exit(0);
            }
        });
        fileMenu.add(exitMenuItem);
        JMenuItem mi;
        mi = fileMenu.add(new JMenuItem("Cut", 't'));
        mi.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, Event.CTRL_MASK));
        mi.addActionListener(l);
        mi = fileMenu.add(new JMenuItem("Copy", 'c'));
        mi.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, Event.CTRL_MASK));
        mi.addActionListener(l);
        mi = fileMenu.add(new JMenuItem("Paste", 'p'));
        mi.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, Event.CTRL_MASK));
        mi.addActionListener(l);



        //new Menu();
        frame.setJMenuBar(menuBar);

        frame.add(tp1);
        //frame.add(tp2);

        frame.setVisible(true);
    }
}
